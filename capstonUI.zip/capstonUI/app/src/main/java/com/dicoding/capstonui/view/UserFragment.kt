package com.dicoding.capstonui.view

class UserFragment {
}